import { pgTable, text, serial, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const activities = pgTable("activities", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'transport', 'food', 'energy'
  category: text("category").notNull(), // specific category like 'car', 'beef', 'heating'
  value: real("value").notNull(), // distance, serving size, hours, etc.
  unit: text("unit").notNull(), // km, serving, hours
  emissions: real("emissions").notNull(), // calculated CO2 in kg
  details: text("details").notNull(), // human readable description
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertActivitySchema = createInsertSchema(activities).omit({
  id: true,
  createdAt: true,
});

export type InsertActivity = z.infer<typeof insertActivitySchema>;
export type Activity = typeof activities.$inferSelect;

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  homeSize: integer("home_size"), // square feet for energy calculations
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  homeSize: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
