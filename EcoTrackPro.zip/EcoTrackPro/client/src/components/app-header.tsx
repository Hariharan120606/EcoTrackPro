import { Link, useLocation } from "wouter";
import { Leaf, Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";

export function AppHeader() {
  const [location] = useLocation();

  const navigation = [
    { name: 'Dashboard', href: '/', active: location === '/' },
    { name: 'Log Activity', href: '#logging', active: false },
    { name: 'History', href: '#history', active: false },
    { name: 'Insights', href: '#insights', active: false },
  ];

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 bg-primary rounded-full flex items-center justify-center">
              <Leaf className="text-white text-xl" />
            </div>
            <h1 className="text-2xl font-bold text-primary">EcoTracker</h1>
          </div>
          
          <nav className="hidden md:flex space-x-6">
            {navigation.map((item) => (
              <a
                key={item.name}
                href={item.href}
                className={`${
                  item.active
                    ? 'text-primary font-medium border-b-2 border-primary pb-1'
                    : 'text-text-secondary hover:text-primary transition-colors'
                }`}
              >
                {item.name}
              </a>
            ))}
          </nav>

          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" className="md:hidden">
                <Menu className="text-text-primary text-xl" />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <nav className="flex flex-col space-y-4 mt-8">
                {navigation.map((item) => (
                  <a
                    key={item.name}
                    href={item.href}
                    className="text-text-secondary hover:text-primary transition-colors py-2"
                  >
                    {item.name}
                  </a>
                ))}
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
