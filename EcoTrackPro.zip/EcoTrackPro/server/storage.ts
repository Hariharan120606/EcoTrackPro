import { activities, users, type Activity, type InsertActivity, type User, type InsertUser } from "@shared/schema";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Activity methods
  createActivity(activity: InsertActivity): Promise<Activity>;
  getActivities(dateRange?: { start: Date; end: Date }): Promise<Activity[]>;
  getActivitiesByType(type: string, dateRange?: { start: Date; end: Date }): Promise<Activity[]>;
  getTodayActivities(): Promise<Activity[]>;
  getWeeklyActivities(): Promise<Activity[]>;
  getMonthlyActivities(): Promise<Activity[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private activities: Map<number, Activity>;
  private currentUserId: number;
  private currentActivityId: number;

  constructor() {
    this.users = new Map();
    this.activities = new Map();
    this.currentUserId = 1;
    this.currentActivityId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createActivity(insertActivity: InsertActivity): Promise<Activity> {
    const id = this.currentActivityId++;
    const activity: Activity = { 
      ...insertActivity, 
      id, 
      createdAt: new Date() 
    };
    this.activities.set(id, activity);
    return activity;
  }

  async getActivities(dateRange?: { start: Date; end: Date }): Promise<Activity[]> {
    let activities = Array.from(this.activities.values());
    
    if (dateRange) {
      activities = activities.filter(activity => 
        activity.createdAt >= dateRange.start && activity.createdAt <= dateRange.end
      );
    }
    
    return activities.sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getActivitiesByType(type: string, dateRange?: { start: Date; end: Date }): Promise<Activity[]> {
    const activities = await this.getActivities(dateRange);
    return activities.filter(activity => activity.type === type);
  }

  async getTodayActivities(): Promise<Activity[]> {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    
    return this.getActivities({ start: today, end: tomorrow });
  }

  async getWeeklyActivities(): Promise<Activity[]> {
    const today = new Date();
    const weekAgo = new Date(today);
    weekAgo.setDate(weekAgo.getDate() - 7);
    
    return this.getActivities({ start: weekAgo, end: today });
  }

  async getMonthlyActivities(): Promise<Activity[]> {
    const today = new Date();
    const monthAgo = new Date(today);
    monthAgo.setMonth(monthAgo.getMonth() - 1);
    
    return this.getActivities({ start: monthAgo, end: today });
  }
}

export const storage = new MemStorage();
