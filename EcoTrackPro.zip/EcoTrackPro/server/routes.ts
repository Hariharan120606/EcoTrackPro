import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertActivitySchema } from "@shared/schema";
import { z } from "zod";

// Emission factors (kg CO2 per unit)
const EMISSION_FACTORS = {
  transport: {
    car: { gasoline: 0.21, diesel: 0.19, electric: 0.05, hybrid: 0.12 },
    bus: 0.08,
    train: 0.04,
    bike: 0,
    walk: 0,
    flight: 0.25,
  },
  food: {
    beef: { small: 15, medium: 25, large: 35 },
    pork: { small: 7, medium: 12, large: 18 },
    chicken: { small: 4, medium: 6, large: 9 },
    fish: { small: 3, medium: 5, large: 8 },
    vegetarian: { small: 1, medium: 2, large: 3 },
    vegan: { small: 0.5, medium: 1, large: 1.5 },
  },
  energy: {
    'natural-gas': 0.2, // per hour per 100 sq ft
    electricity: 0.4,
    solar: 0.02,
    renewable: 0.05,
  },
};

async function getWeatherData(city: string = "New York") {
  const apiKey = process.env.OPENWEATHER_API_KEY || process.env.WEATHER_API_KEY || "demo_key";
  try {
    const response = await fetch(
      `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`
    );
    if (!response.ok) {
      console.warn("Weather API failed, using default values");
      return { temp: 20, description: "moderate" };
    }
    const data = await response.json();
    return {
      temp: data.main.temp,
      description: data.weather[0].description,
    };
  } catch (error) {
    console.warn("Weather API error:", error);
    return { temp: 20, description: "moderate" };
  }
}

function calculateEmissions(type: string, category: string, value: number, fuelType?: string, size?: string): number {
  switch (type) {
    case 'transport':
      if (category === 'car' && fuelType) {
        return value * (EMISSION_FACTORS.transport.car[fuelType as keyof typeof EMISSION_FACTORS.transport.car] || 0.21);
      }
      return value * (EMISSION_FACTORS.transport[category as keyof typeof EMISSION_FACTORS.transport] as number || 0);
    
    case 'food':
      const foodEmissions = EMISSION_FACTORS.food[category as keyof typeof EMISSION_FACTORS.food];
      if (typeof foodEmissions === 'object' && size) {
        return foodEmissions[size as keyof typeof foodEmissions] || 0;
      }
      return 0;
    
    case 'energy':
      const factor = EMISSION_FACTORS.energy[category as keyof typeof EMISSION_FACTORS.energy] || 0.2;
      return value * factor * (1200 / 100); // assuming 1200 sq ft default home
    
    default:
      return 0;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get today's activities summary
  app.get("/api/today-summary", async (req, res) => {
    try {
      const activities = await storage.getTodayActivities();
      
      const summary = {
        total: activities.reduce((sum, activity) => sum + activity.emissions, 0),
        transport: activities.filter(a => a.type === 'transport').reduce((sum, a) => sum + a.emissions, 0),
        food: activities.filter(a => a.type === 'food').reduce((sum, a) => sum + a.emissions, 0),
        energy: activities.filter(a => a.type === 'energy').reduce((sum, a) => sum + a.emissions, 0),
        target: 15.0, // daily target in kg CO2
      };
      
      res.json(summary);
    } catch (error) {
      res.status(500).json({ message: "Failed to get today's summary" });
    }
  });

  // Log transport activity
  app.post("/api/activities/transport", async (req, res) => {
    try {
      const data = z.object({
        mode: z.string(),
        distance: z.number(),
        fuelType: z.string().optional(),
      }).parse(req.body);

      const emissions = calculateEmissions('transport', data.mode, data.distance, data.fuelType);
      const details = `${data.distance} km • ${data.mode}${data.fuelType ? ` • ${data.fuelType}` : ''}`;

      const activity = await storage.createActivity({
        type: 'transport',
        category: data.mode,
        value: data.distance,
        unit: 'km',
        emissions,
        details,
      });

      res.json(activity);
    } catch (error) {
      res.status(400).json({ message: "Invalid transport data" });
    }
  });

  // Log food activity
  app.post("/api/activities/food", async (req, res) => {
    try {
      const data = z.object({
        mealType: z.string(),
        protein: z.string(),
        servingSize: z.string(),
      }).parse(req.body);

      const emissions = calculateEmissions('food', data.protein, 1, undefined, data.servingSize);
      const details = `${data.mealType} • ${data.protein} • ${data.servingSize} serving`;

      const activity = await storage.createActivity({
        type: 'food',
        category: data.protein,
        value: 1,
        unit: 'serving',
        emissions,
        details,
      });

      res.json(activity);
    } catch (error) {
      res.status(400).json({ message: "Invalid food data" });
    }
  });

  // Log energy activity
  app.post("/api/activities/energy", async (req, res) => {
    try {
      const data = z.object({
        homeSize: z.number(),
        hours: z.number(),
        energySource: z.string(),
      }).parse(req.body);

      // Get weather data for better estimates
      const weather = await getWeatherData();
      const weatherMultiplier = weather.temp < 10 || weather.temp > 25 ? 1.2 : 1.0;

      const baseEmissions = calculateEmissions('energy', data.energySource, data.hours);
      const emissions = baseEmissions * (data.homeSize / 1200) * weatherMultiplier;
      const details = `${data.hours} hours • ${data.homeSize} sq ft • ${data.energySource}`;

      const activity = await storage.createActivity({
        type: 'energy',
        category: data.energySource,
        value: data.hours,
        unit: 'hours',
        emissions,
        details,
      });

      res.json(activity);
    } catch (error) {
      res.status(400).json({ message: "Invalid energy data" });
    }
  });

  // Get all activities with optional filtering
  app.get("/api/activities", async (req, res) => {
    try {
      const { type, days } = req.query;
      
      let dateRange;
      if (days) {
        const daysAgo = new Date();
        daysAgo.setDate(daysAgo.getDate() - parseInt(days as string));
        dateRange = { start: daysAgo, end: new Date() };
      }

      let activities;
      if (type) {
        activities = await storage.getActivitiesByType(type as string, dateRange);
      } else {
        activities = await storage.getActivities(dateRange);
      }

      res.json(activities);
    } catch (error) {
      res.status(500).json({ message: "Failed to get activities" });
    }
  });

  // Get weekly chart data
  app.get("/api/chart/weekly", async (req, res) => {
    try {
      const activities = await storage.getWeeklyActivities();
      
      // Group by day
      const dailyData = new Map();
      const today = new Date();
      
      // Initialize past 7 days
      for (let i = 6; i >= 0; i--) {
        const date = new Date(today);
        date.setDate(date.getDate() - i);
        const key = date.toISOString().split('T')[0];
        dailyData.set(key, 0);
      }
      
      // Sum emissions by day
      activities.forEach(activity => {
        const key = activity.createdAt.toISOString().split('T')[0];
        if (dailyData.has(key)) {
          dailyData.set(key, dailyData.get(key) + activity.emissions);
        }
      });
      
      const labels = Array.from(dailyData.keys()).map(date => {
        const d = new Date(date);
        return d.toLocaleDateString('en', { weekday: 'short' });
      });
      
      const data = Array.from(dailyData.values());
      
      res.json({ labels, data });
    } catch (error) {
      res.status(500).json({ message: "Failed to get weekly data" });
    }
  });

  // Get category breakdown
  app.get("/api/chart/categories", async (req, res) => {
    try {
      const activities = await storage.getTodayActivities();
      
      const categories = {
        transport: activities.filter(a => a.type === 'transport').reduce((sum, a) => sum + a.emissions, 0),
        food: activities.filter(a => a.type === 'food').reduce((sum, a) => sum + a.emissions, 0),
        energy: activities.filter(a => a.type === 'energy').reduce((sum, a) => sum + a.emissions, 0),
      };
      
      res.json({
        labels: ['Transport', 'Food', 'Energy'],
        data: [categories.transport, categories.food, categories.energy],
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get category data" });
    }
  });

  // Get monthly comparison
  app.get("/api/chart/monthly", async (req, res) => {
    try {
      const activities = await storage.getMonthlyActivities();
      
      // Group by month and category
      const monthlyData = new Map();
      const today = new Date();
      
      // Initialize past 6 months
      for (let i = 5; i >= 0; i--) {
        const date = new Date(today.getFullYear(), today.getMonth() - i, 1);
        const key = date.toISOString().slice(0, 7); // YYYY-MM
        monthlyData.set(key, { transport: 0, food: 0, energy: 0 });
      }
      
      // Sum emissions by month and category
      activities.forEach(activity => {
        const key = activity.createdAt.toISOString().slice(0, 7);
        if (monthlyData.has(key)) {
          const monthData = monthlyData.get(key);
          monthData[activity.type as keyof typeof monthData] += activity.emissions;
        }
      });
      
      const labels = Array.from(monthlyData.keys()).map(month => {
        const date = new Date(month + '-01');
        return date.toLocaleDateString('en', { month: 'short' });
      });
      
      const transportData = Array.from(monthlyData.values()).map(d => d.transport);
      const foodData = Array.from(monthlyData.values()).map(d => d.food);
      const energyData = Array.from(monthlyData.values()).map(d => d.energy);
      
      res.json({
        labels,
        datasets: [
          { label: 'Transport', data: transportData },
          { label: 'Food', data: foodData },
          { label: 'Energy', data: energyData },
        ],
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get monthly data" });
    }
  });

  // Get recommendations
  app.get("/api/recommendations", async (req, res) => {
    try {
      const activities = await storage.getWeeklyActivities();
      const recommendations = [];
      
      // Analyze transport patterns
      const transportEmissions = activities.filter(a => a.type === 'transport').reduce((sum, a) => sum + a.emissions, 0);
      if (transportEmissions > 20) {
        recommendations.push({
          type: 'transport',
          title: 'Try Cycling',
          description: 'Based on your commute pattern, cycling 2 days per week could save 8.4 kg CO₂ monthly.',
          savings: '8.4 kg/month',
          icon: 'bicycle',
        });
      }
      
      // Analyze food patterns
      const foodEmissions = activities.filter(a => a.type === 'food').reduce((sum, a) => sum + a.emissions, 0);
      if (foodEmissions > 25) {
        recommendations.push({
          type: 'food',
          title: 'Reduce Meat',
          description: 'Replacing beef with chicken twice a week could reduce your food emissions by 15%.',
          savings: '6.2 kg/month',
          icon: 'seedling',
        });
      }
      
      // Analyze energy patterns
      const energyEmissions = activities.filter(a => a.type === 'energy').reduce((sum, a) => sum + a.emissions, 0);
      if (energyEmissions > 15) {
        recommendations.push({
          type: 'energy',
          title: 'Adjust Thermostat',
          description: 'Lowering your thermostat by 2°C could reduce energy emissions by 12%.',
          savings: '3.8 kg/month',
          icon: 'thermometer-half',
        });
      }
      
      res.json(recommendations);
    } catch (error) {
      res.status(500).json({ message: "Failed to get recommendations" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
